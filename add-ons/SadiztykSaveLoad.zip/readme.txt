Super Metroid save/load routine expansion v1.0
Made by Scyzer

**Free space used from $81:EF20 (0x00EF20) to $81:F0A4 (0x00F0A4)**

This patch/asm file will modify the saving and loading routine of Super Metroid for the SNES.
The most basic function is that is will change how maps are stored and loaded, meaning you will be able to use the ENTIRE map for all areas.
Debug is still not supported due to space limitations, but there is no map for this area anyway, so...

KejMap is made completely redundant by this patch, so dont bother applying it (it won't do anything if you already have)

There's a few other bits and pieces for more experienced hackers:
	$100 bytes of ram from $7F:FE00 to $7F:FEFF is saved per file.
		You can modify this ram, and it will still be the same when you load the game.
	$100 bytes of ram from $7F:FF00 to $7F:FFFF is saved GLOBALLY.
		Any ram here will apply to ALL 3 save game files (including if you clear all save games). Deleting the .srm file will remove these changes.
	

Those of you who find joy in cheating by modifying the SRAM files will find your save files deleted.